import { useParams, useNavigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import axios from 'axios';
import { toast } from 'react-toastify';

const EditUser = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [userData, setUserData] = useState({ first_name: '', last_name: '', email: '' });

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const res = await axios.get(`https://reqres.in/api/users/${id}`);
        const { first_name, last_name, email } = res.data.data;
        setUserData({ first_name, last_name, email });
      } catch {
        toast.error('Failed to fetch user');
      }
    };
    fetchUser();
  }, [id]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.put(`https://reqres.in/api/users/${id}`, userData);
      toast.success('User updated!');
      navigate('/users');
    } catch {
      toast.error('Update failed');
    }
  };

  return (
    <div style={{ padding: '2rem' }}>
      <h2>Edit User</h2>
      <form onSubmit={handleSubmit}>
        <input value={userData.first_name} onChange={(e) => setUserData({ ...userData, first_name: e.target.value })} placeholder="First Name" />
        <input value={userData.last_name} onChange={(e) => setUserData({ ...userData, last_name: e.target.value })} placeholder="Last Name" />
        <input value={userData.email} onChange={(e) => setUserData({ ...userData, email: e.target.value })} placeholder="Email" />
        <button type="submit">Save</button>
      </form>
    </div>
  );
};

export default EditUser;
