import { useEffect, useState } from 'react';
import axios from 'axios';
import { Link, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';

const UserList = () => {
  const [users, setUsers] = useState([]);
  const [page, setPage] = useState(1);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const res = await axios.get(`https://reqres.in/api/users?page=${page}`);
        setUsers(res.data.data);
      } catch (err) {
        toast.error('Failed to fetch users');
      }
    };
    fetchUsers();
  }, [page]);

  const handleLogout = () => {
    sessionStorage.removeItem('token');
    navigate('/');
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`https://reqres.in/api/users/${id}`);
      toast.success('User deleted!');
      setUsers(users.filter((user) => user.id !== id));
    } catch (err) {
      toast.error('Failed to delete user');
    }
  };

  return (
    <div style={{ padding: '1rem' }}>
      <h2>User List</h2>
      <button onClick={handleLogout}>Logout</button>
      <div>
        {users.map((user) => (
          <div key={user.id} style={{ border: '1px solid #ccc', padding: 8 }}>
            <img src={user.avatar} width="50" alt="avatar" />
            <p>{user.first_name} {user.last_name}</p>
            <p>{user.email}</p>
            <Link to={`/edit/${user.id}`}>Edit</Link>
            <button onClick={() => handleDelete(user.id)}>Delete</button>
          </div>
        ))}
      </div>
      <div>
        <button onClick={() => setPage((p) => Math.max(1, p - 1))}>Prev</button>
        <button onClick={() => setPage((p) => p + 1)}>Next</button>
      </div>
    </div>
  );
};

export default UserList;
